# Murena Verifier (Anchor, devnet)

Emits `PaymentReceipt` events for the Murena Pay demo.

## Build & Deploy (devnet)
```bash
anchor build
anchor deploy --provider.cluster devnet
```
Then update program ID everywhere:
- `programs/murena_verifier/src/lib.rs` → `declare_id!(...)`
- `Anchor.toml` `[programs.devnet]`
- Relayer `.env` → `VERIFIER_PROGRAM_ID`
- Web `.env.local` → `NEXT_PUBLIC_PROGRAM_ID`

### Discriminator for relayer
Compute 8-byte discriminator for `submit_receipt`:
`sha256("global:submit_receipt")[..8]`
Paste those 8 bytes into `buildIxData` in the relayer.
