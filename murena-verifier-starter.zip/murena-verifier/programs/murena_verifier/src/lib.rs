use anchor_lang::prelude::*;

declare_id!("MuReNa1111111111111111111111111111111"); // replace after deploy

#[program]
pub mod murena_verifier {
    use super::*;
    /// Accepts a receipt hash and memo hash, emits a PaymentReceipt event.
    pub fn submit_receipt(ctx: Context<SubmitReceipt>, receipt_hash: [u8; 32], memo_hash: [u8; 32]) -> Result<()> {
        emit!(PaymentReceipt {
            payer: ctx.accounts.payer.key(),
            merchant: ctx.accounts.merchant.key(),
            receipt_hash,
            memo_hash,
            slot: Clock::get()?.slot,
        });
        Ok(())
    }
}

#[derive(Accounts)]
pub struct SubmitReceipt<'info> {
    /// CHECK: demo-only; merchant identity
    pub merchant: UncheckedAccount<'info>,
    /// CHECK: demo-only; payer identity (signer in a real flow)
    #[account(signer)]
    pub payer: UncheckedAccount<'info>,
}

#[event]
pub struct PaymentReceipt {
    pub payer: Pubkey,
    pub merchant: Pubkey,
    pub receipt_hash: [u8; 32],
    pub memo_hash: [u8; 32],
    pub slot: u64,
}
